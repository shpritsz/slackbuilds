#pragma once
#include <string>

namespace waybar::util {
std::string sanitize_string(std::string str);
}  // namespace waybar::util
