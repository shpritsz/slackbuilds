---
name: Enhancements
about: New functionality
labels: 'enhancement'

---

### Please read the following before submitting:
- We are not accepting any new window management features unless they get implemented by i3.

### Please fill out the following:
- **Description:**
Please describe in plain English what the enhancement is and what the use case is.
