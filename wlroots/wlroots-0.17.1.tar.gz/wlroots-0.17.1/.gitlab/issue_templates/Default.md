<!--

Please read the following before submitting:

- If you are a user of a wlroots-based compositor, please report first your
  issue to your compositor's issue tracker. The issue you are experiencing
  might be a compositor bug rather than a wlroots bug.
- Do not open issues related to proprietary drivers.
- Do not use this issue tracker for questions. Instead, use the IRC channel
  (#wlroots on Libera Chat).
- Please attach full debug logs of your compositor (redact information you
  might consider sensitive). For crashes, please attach a full stack trace with
  debug symbols.

-->
